
ReadMe.txt for sam-help.zip :
---------------------------

sam-help.zip contains the help files for my formula collection. Unzip 
the whole file in the "formula" subdirectory of your Ultrafractal 
directory. The help files will be set in a folder called sam-help. 
You'll be able to load them from UF (little blue question mark).

You can visit my fractal page and update these file here :

http://www.p-gallery.net

Good fractalling !

Samuel